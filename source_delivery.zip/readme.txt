=== Folding Blocks Compilation Instructions ===
1. Download Unity (version 2019.2.14f1 was used)
2. Open Project on "src" folder
3. Press "Play" on editor

OR

Alternatively, a Windows build was included for ease of access

=== Usage ===
If you have built the Unity project, a folder will be generated with the file "Folding Blocks.exe" that may be run to play.

The main menu allows for the choice of AI or Human modes:
- In AI mode, you may specify a method of search aswell as a level, to solve selected level with the method chosen
- In Human mode, you may specify a level to play yourself, with optional hints that use A*

=============